# Troubleshooting Guide

Error handling patterns, common failures, and debugging techniques for the Stellar Flutter SDK.

All code assumes the standard SDK import:

```dart
import 'package:stellar_flutter_sdk/stellar_flutter_sdk.dart';
```

- [Exception Hierarchy](#exception-hierarchy)
- [Horizon HTTP Error Handling](#horizon-http-error-handling)
- [Transaction Failure Debugging](#transaction-failure-debugging)
- [Common Error Patterns and Solutions](#common-error-patterns-and-solutions)
- [Address and Key Decoding Errors](#address-and-key-decoding-errors)
- [Soroban RPC Error Handling](#soroban-rpc-error-handling)
- [Debugging Techniques](#debugging-techniques)
- [Common Mistakes](#common-mistakes)
- [Platform & Environment](#platform--environment)

## Exception Hierarchy

| Exception | Source | Fields |
|-----------|--------|--------|
| `ErrorResponse` | Horizon HTTP errors (4xx/5xx) | `code` (int), `body` (String) |
| `TooManyRequestsException` | HTTP 429 rate limiting | `retryAfter` (int?, seconds) |
| `SubmitTransactionTimeoutResponseException` | HTTP 504 on tx submit | `type`, `title`, `status`, `detail` |
| `FormatException` | Strkey decoding, XDR-JSON decoding | `message` (String) |
| `ArgumentError` | Raw key material of the wrong width | `message` (Object?) |

`ArgumentError` extends `Error`, not `Exception`, so `on Exception catch` does not catch it. See [Address and Key Decoding Errors](#address-and-key-decoding-errors).

Soroban RPC errors use a different pattern -- all responses extend `SorobanRpcResponse` which has an `error` field of type `SorobanRpcErrorResponse?` and a computed `isErrorResponse` getter.

## Horizon HTTP Error Handling

```dart
try {
  AccountResponse account = await sdk.accounts.account(accountId);
  print('Balance: ${account.balances.first.balance}');
} on ErrorResponse catch (e) {
  switch (e.code) {
    case 400: print('Bad request: ${e.body}'); break;
    case 404: print('Account not found: $accountId'); break;
    case 500: print('Horizon server error: ${e.body}'); break;
    default:  print('HTTP ${e.code}: ${e.body}');
  }
} on TooManyRequestsException catch (e) {
  final int waitSeconds = e.retryAfter ?? 5;
  await Future.delayed(Duration(seconds: waitSeconds));
} catch (e) {
  print('Network or unexpected error: $e');
}
```

### Common HTTP Status Codes

| Status | Meaning | Typical Cause |
|--------|---------|---------------|
| 400 | Bad Request | Malformed transaction, invalid parameters |
| 404 | Not Found | Account/transaction/resource does not exist |
| 429 | Too Many Requests | Rate limit exceeded; check `retryAfter` |
| 500 | Internal Server Error | Horizon server issue |
| 504 | Gateway Timeout | Horizon overloaded or transaction took too long |

## Transaction Failure Debugging

When a transaction fails, `SubmitTransactionResponse.success` returns `false`. Diagnostic data is available through the `extras` field.

```dart
try {
  SubmitTransactionResponse response =
      await sdk.submitTransaction(transaction);

  if (response.success) {
    print('Success! Hash: ${response.hash}');
  } else {
    SubmitTransactionResponseExtras? extras = response.extras;
    if (extras != null) {
      ExtrasResultCodes? codes = extras.resultCodes;
      if (codes != null) {
        print('Transaction error: ${codes.transactionResultCode}');
        List<String?>? opCodes = codes.operationsResultCodes;
        if (opCodes != null) {
          for (int i = 0; i < opCodes.length; i++) {
            print('  Operation $i: ${opCodes[i]}');
          }
        }
      }
      print('Result XDR: ${extras.resultXdr}');
    }
  }
} on SubmitTransactionTimeoutResponseException catch (e) {
  print('Submission timed out (504): ${e.detail}');
  // Transaction may still succeed -- poll by hash
} catch (e) {
  print('Submission error: $e');
}
```

### Key Result Code Fields

`ExtrasResultCodes` contains:
- `transactionResultCode` -- transaction-level code (e.g., `tx_failed`, `tx_bad_seq`)
- `operationsResultCodes` -- per-operation codes (e.g., `op_underfunded`, `op_no_trust`)

When `transactionResultCode` is `tx_failed`, individual operations report their own codes in `operationsResultCodes`.

### Transaction Result Codes Reference

| Code | Cause | Solution |
|------|-------|----------|
| `tx_failed` | One or more operations failed | Check operation result codes |
| `tx_bad_seq` | Sequence number mismatch | Reload account, rebuild transaction |
| `tx_insufficient_fee` | Fee below network minimum | Increase base fee or check fee stats |
| `tx_bad_auth` | Invalid signature or insufficient weight | Verify signer key and threshold weights |
| `tx_no_source_account` | Source account does not exist | Create/fund the account first |
| `tx_too_early` | Current time before minTime bound | Adjust TimeBounds or wait |
| `tx_too_late` | Current time past maxTime bound | Rebuild with new TimeBounds |
| `tx_insufficient_balance` | Account lacks XLM for fee + reserves | Fund the source account |

### Operation Result Codes Reference

| Code | Cause | Solution |
|------|-------|----------|
| `op_underfunded` | Insufficient balance for payment | Check available balance minus reserves |
| `op_no_trust` | Destination has no trustline for asset | Destination must call `ChangeTrustOperation` first |
| `op_not_authorized` | Asset requires authorization | Issuer must authorize the trustline |
| `op_line_full` | Destination trustline at limit | Destination must increase trust limit |
| `op_no_destination` | Destination account does not exist | Create account first or verify address |
| `op_low_reserve` | Below minimum XLM reserve | Add XLM to cover base reserve (0.5 XLM per entry) |
| `op_already_exists` | Offer/entry already exists | Use update instead of create |
| `op_no_issuer` | Asset issuer account not found | Verify issuer account ID |
| `op_bad_auth` | Insufficient signature weight for multi-sig | Check signer weights vs operation thresholds |

---

## Common Error Patterns and Solutions

### Insufficient Balance (op_underfunded)

**Cause:** Source account does not have enough XLM (or asset) to cover the payment amount plus reserves.

**Solution:** Check the source balance before building the transaction:

```dart
AccountResponse account = await sdk.accounts.account(accountId);
for (Balance balance in account.balances) {
  if (balance.assetType == Asset.TYPE_NATIVE) {
    print('XLM balance: ${balance.balance}');
  }
}
```

Account minimum balance = `(2 + subentryCount) * 0.5 XLM`. Funds below this minimum cannot be spent.

### Missing Trustline (op_no_trust)

**Cause:** The destination account has no trustline for the asset being sent.

**Solution:** The recipient must establish a trustline before receiving the asset:

```dart
AccountResponse account =
    await sdk.accounts.account(recipientKeyPair.accountId);
Transaction transaction = TransactionBuilder(account)
    .addOperation(ChangeTrustOperationBuilder(asset).build())
    .build();
transaction.sign(recipientKeyPair, Network.TESTNET);
await sdk.submitTransaction(transaction);
```

### Account Not Found (404 ErrorResponse)

**Cause:** The account does not exist on the network (never funded or merged).

**Solution:** Create the account with `CreateAccountOperation` or fund via Friendbot on testnet:

```dart
KeyPair newKeyPair = KeyPair.random();
bool funded = await FriendBot.fundTestAccount(newKeyPair.accountId);
```

### Bad Sequence Number (tx_bad_seq)

**Cause:** The transaction's sequence number does not match the account's current sequence number + 1. Common scenarios:
- Loading an account, submitting a transaction, then building another from the same account object loaded separately
- Two code paths loading the same account and building transactions concurrently

**Key behavior:** `TransactionBuilder.build()` **mutates** the source account object's sequence number. After `build()`, the account object's sequence is incremented internally. This means:

```dart
// CORRECT: reload account, build() increments sequence internally
AccountResponse account = await sdk.accounts.account(accountId);  // on-chain seq N
Transaction tx = TransactionBuilder(account)
    .addOperation(op).build();  // tx uses seq N+1, account object now at N+1
await sdk.submitTransaction(tx);  // on-chain seq advances to N+1

// WRONG: manually incrementing — build() already does this
// account.incrementSequenceNumber(); // now N+1
// Transaction tx = TransactionBuilder(account).build(); // uses N+2 — tx_bad_seq!

// SAFE: building multiple transactions from the SAME account object
// build() auto-advances, so sequential builds work:
Transaction tx1 = TransactionBuilder(account).addOperation(op1).build(); // uses N+1
Transaction tx2 = TransactionBuilder(account).addOperation(op2).build(); // uses N+2
// Submit tx1 first, then tx2 — both succeed in order.
```

### Rate Limiting (429 TooManyRequestsException)

**Solution:** Implement exponential backoff:

```dart
Future<AccountResponse> fetchWithRetry(
  StellarSDK sdk, String accountId, {int maxRetries = 3}
) async {
  for (int attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await sdk.accounts.account(accountId);
    } on TooManyRequestsException catch (e) {
      final int waitSeconds = e.retryAfter ?? (2 * (attempt + 1));
      if (attempt == maxRetries - 1) rethrow;
      await Future.delayed(Duration(seconds: waitSeconds));
    }
  }
  throw Exception('Max retries exceeded');
}
```

---

## Address and Key Decoding Errors

`StrKey.decode*` reports every rejection as a `FormatException`, so one `catch` covers the decoding side of the codec. The message names the check that failed. The encode direction is different: the `encode*` methods and the `SignedPayloadSigner` constructor raise a plain `Exception`, for a payload of a width the type does not admit or a discriminant that names no type.

```dart
import 'dart:typed_data';

void decodeAccountId() {
  String userInput = 'GINVALIDADDRESS'; // e.g. a truncated paste, 15 characters
  try {
    Uint8List raw = StrKey.decodeStellarAccountId(userInput);
    print('${raw.length} bytes'); // 32 bytes
  } on FormatException catch (e) {
    print(e.message); // Encoded string must be 56 characters, got 15
  }
}
```

### FormatException messages

Checks run in this order, so the first failing one is the message you get.

| Message | Cause |
|---------|-------|
| `Unrecognized version byte 99` | The `VersionByte` names no strkey type. Only reachable through `decodeCheck` or `encodeCheck` called with a hand-built `VersionByte`; the named `decode*` and `encode*` methods always pass a known one. |
| `Encoded string must be 56 characters, got 15` | The string length is outside the range the type admits. Checked before base32 decoding, so an empty or one-character input lands here. |
| `Invalid encoded string` | The string is not the base32 rendering of the bytes it decodes to: a character outside `A-Z` and `2-7`, an `=` padding character, or trailing bits that do not round-trip. |
| `Version byte is invalid` | The address belongs to another strkey type, for example a `G...` passed to `decodeSha256Hash`. |
| `Checksum invalid` | The trailing CRC-16 does not match the payload. A typo or a truncated copy of an otherwise well-formed address. |
| `Decoded signed payload carries an empty payload, which has no strkey rendering` | A `P...` address declaring a payload length of 0. |
| `Decoded signed payload carries a 65536-byte payload, more than the declared maximum of 64` | A `P...` address declaring more than 64 payload bytes. |
| `Decoded signed payload is 40 bytes, but a 5-byte payload occupies 44` | A `P...` address whose total width disagrees with the length it declares. |
| `Decoded signed payload pads its payload with a byte that is not NUL` | A `P...` address padded with something other than NUL. |
| `Decoded claimable balance id carries the discriminant 1, which names no claimable balance id type` | A `B...` address leading with a discriminant other than `CLAIMABLE_BALANCE_ID_TYPE_V0`, whose value is zero. |

A `Decoded payload must be ... bytes, got ...` message backs the encoded-length check after the checksum. It cannot be reached through the public `decode*` methods, because the length check already fixes the payload width.

Decoding a strkey from XDR-JSON restates the codec's message inside the XDR-JSON contract, keeping the wording:

```dart
// XDR-JSON XdrClaimableBalanceID holds a malformed strkey:
// "BAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA..."
// (Decoded claimable balance id carries the discriminant 1, which names no
// claimable balance id type)
```

### Errors that are not FormatException

The encoding direction and the raw-byte constructors report their own types. Message text is shown as stored; `print(e)` prefixes it with `Exception:` or `Invalid argument(s):`.

| Type | Message | Source |
|------|---------|--------|
| `ArgumentError` | `Public key must be 32 bytes, got 31` | `KeyPair.fromPublicKey` |
| `ArgumentError` | `Secret seed must be 32 bytes, got 31` | `KeyPair.fromSecretSeedList` |
| `Exception` | `invalid payload length, must be at least 1` | `SignedPayloadSigner` with an empty payload |
| `Exception` | `invalid payload length, must be at most 64` | `SignedPayloadSigner` with more than 64 bytes |
| `Exception` | `Payload must be 32 bytes, got 31` | any `encode*` method with a payload of a width its type does not admit |
| `Exception` | `claimable balance id must be 32 bytes (the hash), 33 bytes (the hash behind its discriminant), or 36 bytes (its XDR encoding), got 34` | `encodeClaimableBalanceId` with any other width |
| `Exception` | `claimable balance id carries the discriminant 1, which names no claimable balance id type` | `encodeClaimableBalanceId` with a 33-byte value whose first byte is not zero |
| `Exception` | `claimable balance id carries an XDR discriminant that names no claimable balance id type` | `encodeClaimableBalanceId` with a 36-byte value not opening with four zero bytes |

`ArgumentError` is an `Error`, so `on Exception catch` will not catch the two `KeyPair` cases. Catch `ArgumentError`, or check the width before the call.

```dart
import 'dart:typed_data';

// The raw seed and the transaction to sign enter as parameters.
void signWithRawSeed(Uint8List seedBytes, Transaction transaction) {
  try {
    KeyPair signer = KeyPair.fromSecretSeedList(seedBytes);
    transaction.sign(signer, Network.TESTNET);
  } on ArgumentError catch (e) {
    print(e); // Invalid argument(s): Secret seed must be 32 bytes, got 31
  }
}
```

### Choosing between decode and isValid

The `isValid*` methods run the matching decoder and return false instead of throwing, so they classify input without a `try`. They tell you nothing about why a value failed. When one type is expected, call `decode*` and read the message.

---

## Soroban RPC Error Handling

Soroban uses `SorobanServer` with JSON-RPC. Errors appear at two levels: RPC-level errors (on the `SorobanRpcResponse.error` field) and application-level errors (like `SimulateTransactionResponse.resultError`).

### Simulation Errors

```dart
SimulateTransactionResponse simResponse = await server
    .simulateTransaction(SimulateTransactionRequest(transaction));

// Check RPC-level error
if (simResponse.isErrorResponse) {
  print('RPC error: ${simResponse.error!.code} ${simResponse.error!.message}');
  return;
}

// Check simulation-level error
if (simResponse.resultError != null) {
  print('Simulation failed: ${simResponse.resultError}');
  return;
}

// Check if entries need restoration before invocation
if (simResponse.restorePreamble != null) {
  print('Expired entries detected -- restore footprint first');
  // Build and submit a RestoreFootprint transaction before retrying
  // See soroban_contracts.md > Restore Expired Data
  return;
}

// Simulation succeeded -- apply results to transaction
transaction.sorobanTransactionData = simResponse.transactionData;
transaction.addResourceFee(simResponse.minResourceFee!);
transaction.setSorobanAuth(simResponse.sorobanAuth);
```

### SendTransaction Status Codes

```dart
SendTransactionResponse sendResponse = await server.sendTransaction(tx);

switch (sendResponse.status) {
  case SendTransactionResponse.STATUS_PENDING:
    // Accepted -- poll getTransaction() for final result
    break;
  case SendTransactionResponse.STATUS_DUPLICATE:
    // Already submitted -- poll getTransaction() with the hash
    break;
  case SendTransactionResponse.STATUS_TRY_AGAIN_LATER:
    // Network congestion -- wait and retry
    await Future.delayed(Duration(seconds: 5));
    break;
  case SendTransactionResponse.STATUS_ERROR:
    // Submission failed
    print('Error: ${sendResponse.errorResultXdr}');
    break;
}
```

### Soroban-Specific Errors

**Simulation failure** (`SimulateTransactionResponse.resultError`):
- Contract function does not exist
- Wrong number or type of arguments
- Contract logic reverted (e.g., assertion failed)
- Insufficient authorization

**Expired ledger entries** (`SimulateTransactionResponse.restorePreamble` non-null): Archived state must be restored before invoking. See [Soroban Contracts](./soroban_contracts.md) > Restore Expired Data.

**Resource limits exceeded:** If simulation succeeds but `sendTransaction` returns `STATUS_ERROR`, add a buffer to `minResourceFee`:

```dart
// Add 15% buffer to resource fee
int bufferedFee = (simResponse.minResourceFee! * 1.15).ceil();
transaction.addResourceFee(bufferedFee);
```

**Delegated auth (WITH_DELEGATES) submission fails:** after `setSorobanAuth`, the initial simulation excluded the delegate authorization, so its resources are understated — re-simulate with the delegated entry attached and apply the returned `sorobanTransactionData` / `addResourceFee` before submitting. Multiple G-address signatures on one node must be added in ascending public-key order (the SDK appends in call order, no sorting).

**V2 entries on an old network:** emitting `ADDRESS_V2` / `WITH_DELEGATES` below protocol 27 invalidates the tx — set `useUpgradedAuth: false` there and build legacy entries via the `forAddressLegacy` / `forAddressCredentialsLegacy` factories. If simulation with `useUpgradedAuth` at its default (`true`) still yields legacy `ADDRESS` entries, the RPC does not support the flag (silently ignored) or the simulation did not run in recording mode — detect support by inspecting `credentials.arm`, never by an error code.

**Switch no longer compiles after upgrade:** the new union cases on `SorobanCredentials` / `XdrSorobanCredentialsType` / `XdrEnvelopeType` / `XdrHashIDPreimage` require a `default` arm in exhaustive switches.

---

## Debugging Techniques

1. **Enable Soroban logging:** Set `server.enableLogging = true` on `SorobanServer` to see raw JSON-RPC request/response pairs in the console.

2. **Inspect transaction XDR before submission:**
   ```dart
   String envelopeXdr = transaction.toEnvelopeXdrBase64();
   // Paste into Stellar Laboratory XDR viewer to inspect contents
   ```

3. **Decode failed transaction results:**
   ```dart
   XdrTransactionResult result =
       XdrTransactionResult.fromBase64EncodedXdrString(resultXdrString);
   print('Result code: ${result.result.discriminant}');
   ```

4. **Check Horizon health:** Use `sdk.health.execute()` to verify the Horizon server is responding before debugging application logic.

5. **Verify network passphrase:** Signing with the wrong network passphrase produces invalid signatures. Confirm `Network.TESTNET` vs `Network.PUBLIC` matches your Horizon/RPC endpoint.

6. **Check transaction status on Horizon after uncertain submission:**
   ```dart
   try {
     TransactionResponse tx = await sdk.transactions.transaction(txHash);
     print('Confirmed in ledger: ${tx.ledger}');
   } on ErrorResponse catch (e) {
     if (e.code == 404) print('Transaction not found -- may still be pending');
   }
   ```

---

## Common Mistakes

**Wrong network passphrase:** Signing with `Network.TESTNET` for a mainnet transaction produces invalid signatures. Always match the Network to your Horizon/RPC endpoint.

**Stale sequence numbers:** Building multiple transactions for the same account without submitting them sequentially causes `tx_bad_seq`. Always reload the account or build from the same account object.

**Insufficient fee for Soroban:** Soroban transactions require a resource fee from simulation on top of the base fee. Always call `simulateTransaction()` first and apply `minResourceFee` via `transaction.addResourceFee()`.

**Missing trustline:** Sending non-native assets to an account without a trustline fails with `op_no_trust`. The destination must execute `ChangeTrustOperation` before receiving the asset.

**XLM reserve requirements:** Every subentry (trustline, offer, data entry, signer) requires 0.5 XLM base reserve. Creating entries without sufficient XLM fails with `op_low_reserve`.

**Forgetting to apply simulation data:** After simulating a Soroban transaction, you must call `sorobanTransactionData =`, `addResourceFee()`, and `setSorobanAuth()` on the transaction before signing and submitting.

**Catching only `Exception` around key construction:** `KeyPair.fromPublicKey` and `KeyPair.fromSecretSeedList` throw `ArgumentError` for a key that is not 32 bytes. `ArgumentError` is an `Error`, so an `on Exception catch` around the call lets it escape.

**Treating a decoded claimable balance ID as 32 bytes:** `decodeClaimableBalanceId` returns 33 bytes -- the discriminant, then the hash. Drop the first byte before comparing against a hash from another source.

---

## Platform & Environment

### Platform Support

| Platform | Status | Notes |
|----------|--------|-------|
| Android  | Full   | Native crypto via pinenacl/pointycastle (pure Dart) |
| iOS      | Full   | Same pure Dart crypto, no platform channels needed |
| Web      | Full   | Since v3.0.0 with BigInt migration, no dart:io deps |

### Crypto Libraries

All cryptographic operations use **pure Dart** libraries with no platform-specific FFI:

- **Ed25519 signing**: `pinenacl` ^0.6.0
- **Cryptographic hashing**: `pointycastle` ^4.0.0 + `crypto` ^3.0.6
- **No native code**: Works identically across all platforms

### Key Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `http` | ^1.5.0 | HTTP client for Horizon requests |
| `dio` | ^5.9.0 | HTTP client for Soroban RPC (JSON-RPC) |
| `pointycastle` | ^4.0.0 | Cryptographic operations |
| `pinenacl` | ^0.6.0 | Ed25519 signing |
| `toml` | ^0.17.0 | stellar.toml parsing (SEP-0001) |
| `decimal` | ^3.2.4 | Precise decimal arithmetic |

### v3.0.0 Breaking Changes (BigInt Migration)

Version 3.0.0 migrated all 64-bit integer types to `BigInt` for JavaScript/web compatibility:

- `Memo.id(id)`: `int` -> `BigInt`
- `MuxedAccount(accountId, id)`: `int?` -> `BigInt?`
- `Account` sequence number: `BigInt`
- `XdrSCVal.forU64/forI64`: `int` -> `BigInt`
- `XdrInt64.int64` / `XdrUint64.uint64`: `int` -> `BigInt`
- Offer IDs (`ManageSellOfferOperationBuilder` etc.): `BigInt`
