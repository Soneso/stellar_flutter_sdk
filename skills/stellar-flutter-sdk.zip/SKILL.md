---
name: stellar-flutter-sdk
description: Builds Stellar blockchain applications in Flutter/Dart using stellar_flutter_sdk. Use when generating Dart code for transaction building, signing, Horizon API queries, Soroban RPC, smart contract deployment and invocation, smart accounts (OpenZeppelin) with passkey / WebAuthn authentication, XDR encoding/decoding, XDR-JSON, and SEP protocol integration, with async/await and Stream patterns across Android, iOS, and Web. Reach for it when the developer mentions Stellar, blockchain, passkey, smart wallet, or biometric signing in a Flutter app.
license: MIT
compatibility: Requires Dart SDK >=3.8.0 <4.0.0 and stellar_flutter_sdk ^3.11.0
metadata:
  version: "1.10.0"
  sdk_version: "3.11.0"
---

# Stellar SDK for Flutter

## Overview

The Stellar Flutter SDK (`stellar_flutter_sdk`) is a full-featured Dart library for building Stellar blockchain applications on Android, iOS, and Web. It covers the Horizon API, the Soroban RPC API, and the SEP implementations listed in the SEP guide. All APIs use Dart `Future` (async/await) for asynchronous operations and `Stream` for real-time event subscriptions. 64-bit integer types are `BigInt`, so the same code runs on the web platform.

## Installation

```yaml
dependencies:
  stellar_flutter_sdk: ^3.11.0
```

> iOS: set the app's deployment target to 15.0 or higher. Passkey smart-account features need iOS 16 at runtime.

> All code examples below assume `import 'package:stellar_flutter_sdk/stellar_flutter_sdk.dart';`

## 1. Stellar Basics

Fundamental Stellar concepts and SDK patterns.

### Keys and KeyPairs

```dart
// Generate new keypair
KeyPair keyPair = KeyPair.random();
String accountId = keyPair.accountId;   // G... public address
String secretSeed = keyPair.secretSeed; // S... secret seed
// IMPORTANT: Store secretSeed securely. Never log or expose it.

// From existing seed
KeyPair restored = KeyPair.fromSecretSeed(secretSeed);
KeyPair publicOnly = KeyPair.fromAccountId(accountId); // public-key-only, cannot sign
```

### Accounts

```dart
KeyPair keyPair = KeyPair.random();
String accountId = keyPair.accountId;

// Fund on testnet using FriendBot (10,000 test XLM)
await FriendBot.fundTestAccount(accountId);

// Query account (a missing account throws a 404 ErrorResponse: Account Not Found in the Troubleshooting Guide)
StellarSDK sdk = StellarSDK.TESTNET;
AccountResponse account = await sdk.accounts.account(accountId);
print('Sequence: ${account.sequenceNumber}');
print('Subentries: ${account.subentryCount}');

for (Balance balance in account.balances) {
  if (balance.assetType == Asset.TYPE_NATIVE) {
    print('XLM: ${balance.balance}');
  } else {
    print('${balance.assetCode}: ${balance.balance}');
  }
}


// Check signers
for (Signer signer in account.signers) {
  // WRONG: signer.ed25519PublicKey -- does NOT exist
  // CORRECT: signer.key returns the public key string, signer.type returns the type
  print('${signer.key} weight=${signer.weight} type=${signer.type}');
}
```

### Assets

```dart
// From your app: asset (Asset, for example balance.asset, operation.asset or offer.selling)
Asset xlm = Asset.NATIVE; // Returns AssetTypeNative instance

// 1-4 char code -> AssetTypeCreditAlphaNum4; 5-12 char -> AssetTypeCreditAlphaNum12
Asset usdc = Asset.createNonNativeAsset('USDC', 'GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN');

// From canonical form
Asset? parsed = Asset.createFromCanonicalForm('USDC:GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN');

// WRONG: asset.assetCode -- Asset base class has NO assetCode property
// CORRECT: For type-specific access, cast to AssetTypeCreditAlphaNum
if (asset is AssetTypeCreditAlphaNum) {
  String code = (asset as AssetTypeCreditAlphaNum).code;
  String issuer = (asset as AssetTypeCreditAlphaNum).issuerId;
}

// BETTER for printing/logging: use canonical form (works for ALL asset types)
String display = Asset.canonicalForm(asset); // "native" for XLM, "USDC:GISSUER..." for custom
print('Asset: $display');
```

### Networks

```dart
// Pre-configured: StellarSDK.TESTNET, StellarSDK.PUBLIC, StellarSDK.FUTURENET
// Network passphrases: Network.TESTNET, Network.PUBLIC, Network.FUTURENET
StellarSDK sdk = StellarSDK.TESTNET;
Network network = Network.TESTNET;

// Custom Horizon
StellarSDK customSdk = StellarSDK('https://my-horizon.example.com');
```

## 2. Horizon API - Fetching Data

Query patterns for retrieving blockchain data. All request builders support `.cursor()`, `.limit()`, `.order()` for pagination.

### Query Accounts

```dart
// From the section Accounts: accountId (String)
StellarSDK sdk = StellarSDK.TESTNET;

// Single account
AccountResponse account = await sdk.accounts.account(accountId);

// Builder pattern: forSigner(), forAsset(), limit(), order(), cursor()
Page<AccountResponse> bySigner = await sdk.accounts
    .forSigner(accountId)
    .limit(10)
    .order(RequestBuilderOrder.DESC)
    .execute();
for (AccountResponse acct in bySigner.records) {
  print('Account: ${acct.accountId}');
}
```

### Query Transactions

```dart
// From the section Accounts: accountId (String)
StellarSDK sdk = StellarSDK.TESTNET;

// Same builder pattern as accounts: forAccount(), limit(), order(), cursor()
Page<TransactionResponse> txPage = await sdk.transactions
    .forAccount(accountId)
    .order(RequestBuilderOrder.DESC)
    .limit(5)
    .execute();

for (TransactionResponse tx in txPage.records) {
  print('${tx.hash} ledger=${tx.ledger}');
}

// Next page: .cursor(txPage.records.last.pagingToken); single tx: sdk.transactions.transaction(hash)
```

For all Horizon endpoints, advanced queries, and pagination patterns:
[Horizon API Reference](./references/horizon_api.md)

## 3. Horizon API - Streaming

Real-time update patterns using Server-Sent Events (SSE). Set cursor to `"now"` for real-time events. Always store the `StreamSubscription` to cancel later.

### Stream Payments

```dart
import 'dart:async';

// From the section Accounts: accountId (String), sdk (StellarSDK)
// Stream pattern: same for payments, transactions, ledgers, operations, effects, offers
StreamSubscription<OperationResponse> subscription = sdk.payments
    .forAccount(accountId)
    .cursor('now')
    .stream()
    .listen((OperationResponse response) {
  if (response is PaymentOperationResponse) {
    print('${response.amount} ${response.assetCode ?? "XLM"} from ${response.from}');
  }
});

// Cancel when no longer needed (e.g., in Flutter widget dispose())
// subscription.cancel();
```

When Horizon sends an SSE `close` event or an event fails to parse, the SDK opens a new connection with the same URI and no last event id. If the response ends without a close event, it does not reconnect. So keep the last `pagingToken` and resubscribe with `.cursor(...)`. Connection failures do not reach `onError` but surface as uncaught asynchronous errors; catch them with `runZonedGuarded` or the app's global error handler and watch for silence. Always cancel subscriptions to prevent resource leaks.

For reconnection patterns and all streaming endpoints:
[Horizon Streaming Guide](./references/horizon_streaming.md)

## 4. Transactions & Operations

Complete transaction lifecycle: Build -> Sign -> Submit.

### Transaction Lifecycle

```dart
// From your app: destinationAccountId (String), senderSecret (String)
StellarSDK sdk = StellarSDK.TESTNET;
Network network = Network.TESTNET;

// 1. Load sender keypair
KeyPair senderKeyPair = KeyPair.fromSecretSeed(senderSecret);
String senderAccountId = senderKeyPair.accountId;

// 2. Fetch source account (provides sequence number)
AccountResponse senderAccount = await sdk.accounts.account(senderAccountId);

// 3. Build transaction (up to 100 operations)
Transaction transaction = TransactionBuilder(senderAccount)
    .addOperation(
      PaymentOperationBuilder(destinationAccountId, Asset.NATIVE, '100.50')
          .build(),
    )
    .addMemo(Memo.text('payment'))
    .setMaxOperationFee(200) // stroops per operation (default: 100)
    .build();

// 4. Sign transaction
transaction.sign(senderKeyPair, network);

// 5. Submit to Horizon
SubmitTransactionResponse response = await sdk.submitTransaction(transaction);
if (response.success) {
  print('Success! Hash: ${response.hash}');
} else {
  print('Failed: ${response.extras?.resultCodes?.transactionResultCode}');
  print('Op codes: ${response.extras?.resultCodes?.operationsResultCodes}');
}
```

### Common Operations

**Change Trust (Establish Trustline):**

```dart
Asset usdc = Asset.createNonNativeAsset('USDC', 'GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN');
Operation trustline = ChangeTrustOperationBuilder(usdc, ChangeTrustOperationBuilder.MAX_LIMIT).build();
// A lower limit instead of the maximum: ChangeTrustOperationBuilder(usdc, '1000.00')
```

**Manage Sell Offer (DEX):**

```dart
Asset selling = AssetTypeNative();
Asset buying = Asset.createNonNativeAsset('USDC', 'GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN');

// Create new offer (offerId defaults to "0" = new offer)
Operation newOffer = ManageSellOfferOperationBuilder(
    selling, buying, '100.0', '0.5')  // sell 100 XLM at 0.5 USDC/XLM
    .build();
```

For every operation with parameters and examples:
[Operations Reference](./references/operations.md)

## 5. Soroban RPC API

RPC endpoint patterns for Soroban smart contract queries.

```dart
SorobanServer server = SorobanServer('https://soroban-testnet.stellar.org:443');
server.enableLogging = true; // optional: debug JSON-RPC requests/responses
GetHealthResponse health = await server.getHealth(); // .status, .latestLedger
```

Assign `server.logger` to route log lines to your sink; without a logger they go to the `dart:developer` log.

For the RPC methods, including event queries and transaction simulation:
[RPC Reference](./references/rpc.md)

## 6. Smart Contracts

Contract deployment and invocation patterns using the high-level `SorobanClient`.

### Deploy Contract

```dart
import 'dart:typed_data';

// From your app: secretSeed (String), wasmBytes (Uint8List)
KeyPair keyPair = KeyPair.fromSecretSeed(secretSeed);
String rpcUrl = 'https://soroban-testnet.stellar.org:443';

// Step 1: Install WASM bytecode (returns wasm hash)
String wasmHash = await SorobanClient.install(
  installRequest: InstallRequest(
    wasmBytes: wasmBytes,
    sourceAccountKeyPair: keyPair,
    network: Network.TESTNET,
    rpcUrl: rpcUrl,
  ),
);

// Step 2: Deploy contract instance
SorobanClient client = await SorobanClient.deploy(
  deployRequest: DeployRequest(
    sourceAccountKeyPair: keyPair,
    wasmHash: wasmHash,
    network: Network.TESTNET,
    rpcUrl: rpcUrl,
    constructorArgs: [XdrSCVal.forSymbol('init')], // optional
  ),
);
print('Contract ID: ${client.getContractId()}');
```

### Invoke Contract Function

```dart
// From your app: contractId (String)
// From the section Deploy Contract: keyPair (KeyPair), rpcUrl (String)
// Create client for an existing contract
SorobanClient client = await SorobanClient.forClientOptions(
  options: ClientOptions(
    sourceAccountKeyPair: keyPair,
    contractId: contractId, // the C... id of the deployed contract
    network: Network.TESTNET,
    rpcUrl: rpcUrl,
  ),
);

// Read call (simulation only)
XdrSCVal result = await client.invokeMethod(name: 'get_count');
print('Count: ${result.u32!.uint32}');

// Write call (simulates, signs, submits automatically)
XdrSCVal incremented = await client.invokeMethod(
  name: 'increment', args: [XdrSCVal.forU32(5)],
);

// Custom fee/timeout: pass methodOptions: MethodOptions(fee: 10000, timeoutInSeconds: 60)
```

For contract authorization, multi-auth workflows, protocol 27 credentials (ADDRESS_V2 / WITH_DELEGATES, `useUpgradedAuth`), and low-level deploy/invoke:
[Smart Contracts Guide](./references/soroban_contracts.md)

## 7. Smart Accounts (OpenZeppelin)

Passkey-authenticated Soroban smart accounts: biometric auth, multiple signers (passkey / delegated / Ed25519), context rules, policies, and optional fee sponsoring via a relayer. Entry point: `OZSmartAccountKit.create(config:)`.

- [Smart Accounts Guide](./references/smart_accounts.md): kit config, wallet create/connect, signer types, transactions, credentials, events, `submit` / `fundWallet`, the `externalSigners` manager, indexer
- [Context Rules & Policies](./references/smart_accounts_policies.md): signer management, context rules, policies, multi-signer operations, common scenarios (recovery, rotation, `__check_auth` debugging), contract error codes
- [WebAuthn Platform Setup](./references/smart_accounts_webauthn.md): Android, iOS, and Web WebAuthn providers and storage adapters, DAL / AASA / RP-ID, cross-device passkeys

## 8. XDR Encoding & Decoding

XDR (External Data Representation) is Stellar's binary serialization format.

### Transaction XDR Roundtrip

```dart
// From the section Transaction Lifecycle: transaction (Transaction)
// Encode: Transaction -> base64 XDR
String xdrBase64 = transaction.toEnvelopeXdrBase64();

// Decode: base64 XDR -> Transaction
AbstractTransaction decoded = AbstractTransaction.fromEnvelopeXdrString(xdrBase64);
if (decoded is Transaction) {
  print('Source: ${decoded.sourceAccount.accountId}, Fee: ${decoded.fee}');
  print('Operations: ${decoded.operations.length}');
}
```

### Working with Soroban XDR Values (XdrSCVal)

```dart
// Common types: forBool(), forU32(), forI64(), forString(), forSymbol(), forBytes(), forVoid()
XdrSCVal symVal  = XdrSCVal.forSymbol('transfer');
XdrSCVal u32Val  = XdrSCVal.forU32(42);
XdrSCVal addrVal = XdrSCVal.forAddress(Address.forAccountId(KeyPair.random().accountId).toXdr());
XdrSCVal u128Val = XdrSCVal.forU128Parts(BigInt.zero, BigInt.from(1000));

// Vec (array of XdrSCVal) and Map (array of XdrSCMapEntry)
XdrSCVal vecVal = XdrSCVal.forVec([XdrSCVal.forU32(1), XdrSCVal.forU32(2)]);
XdrSCVal mapVal = XdrSCVal.forMap([XdrSCMapEntry(symVal, XdrSCVal.forU32(42))]);

// Serialize to/from base64 XDR
String base64 = u32Val.toBase64EncodedXdrString();
XdrSCVal decoded = XdrSCVal.fromBase64EncodedXdrString(base64);
```

### XDR-JSON (SEP-51)

Every generated `Xdr*` type also renders as readable JSON and reads back to the same bytes: `toXdrJson()` / `toXdrJsonValue()` out, static `fromXdrJson(String)` / `fromXdrJsonValue(Object?)` in. 64-bit integers are base-10 strings, opaque fields are lowercase hex, addresses are strkeys, and every rejection is a `FormatException`. Use it for debugging and tooling, not as a network format.

To submit a pre-signed XDR envelope: `sdk.submitTransactionEnvelopeXdrBase64(signedXdrBase64)`.

For all XdrSCVal factory methods and type mapping:
[XDR Reference](./references/xdr.md) | [SEP-51 XDR-JSON](./references/sep-51.md) | [Contract Arguments](./references/soroban_contracts.md)

## 9. Error Handling & Troubleshooting

### Horizon Errors

```dart
// From the section Accounts: accountId (String), sdk (StellarSDK)
try {
  AccountResponse account = await sdk.accounts.account(accountId);
} on ErrorResponse catch (e) {
  // HTTP error: e.code (404, 400, etc.), e.body
  print('Horizon error ${e.code}: ${e.body}');
} on TooManyRequestsException catch (e) {
  // Rate limiting (429): e.retryAfter seconds
  await Future.delayed(Duration(seconds: e.retryAfter ?? 5));
}
```

### Transaction Submission Errors

```dart
// From the section Accounts: sdk (StellarSDK)
// From the section Transaction Lifecycle: transaction (Transaction)
SubmitTransactionResponse response = await sdk.submitTransaction(transaction);
if (!response.success) {
  String? txCode = response.extras?.resultCodes?.transactionResultCode;
  List<String?>? opCodes = response.extras?.resultCodes?.operationsResultCodes;
  print('Transaction: $txCode, Operations: $opCodes');
  // Common: tx_failed (check opCodes), tx_bad_seq (reload account),
  //   tx_insufficient_balance, tx_bad_auth, tx_too_late
}
```

### Soroban RPC Errors

```dart
// From the section Soroban RPC API: server (SorobanServer)
// Health check
GetHealthResponse health = await server.getHealth();
if (health.status != GetHealthResponse.HEALTHY) { /* server unhealthy */ }

// Simulation: check simResponse.resultError, simResponse.restorePreamble
// Send: check sendResponse.status == SendTransactionResponse.STATUS_ERROR
// Poll: check txResponse.status for STATUS_SUCCESS / STATUS_FAILED
```

For the full error catalog and solutions:
[Troubleshooting Guide](./references/troubleshooting.md)

## 10. Security Best Practices

Covers secret key management (use `flutter_secure_storage` on mobile, environment variables on server, never store client-side on web), transaction verification before signing (inspect operations, validate fees), network passphrase validation, address validation via `StrKey` (decoding is strict on length, checksum and per-type framing, and every rejection is a `FormatException`), and amount precision checks (at most seven significant fractional digits after trailing zeros are ignored).

For complete security patterns and platform-specific key storage:
[Security Guide](./references/security.md)

## 11. SEP Implementations

The Flutter SDK implements Stellar Ecosystem Proposals (SEPs) for authentication, deposit/withdrawal, federation, KYC, contract metadata and specs, XDR-JSON, and more. Most have a reference page; SEP-46, SEP-47, and SEP-48 are covered by the Smart Contracts Guide, and SEP-23 (StrKey) inside other topics.

For all SEP examples with code: [SEP Implementations Guide](./references/sep.md)

## Reference Documentation

- [Operations Reference](./references/operations.md) - Stellar operations with examples
- [Horizon API Reference](./references/horizon_api.md) - Horizon endpoints and query builders
- [Horizon Streaming Guide](./references/horizon_streaming.md) - SSE patterns for all streaming endpoints
- [RPC Reference](./references/rpc.md) - Soroban RPC methods
- [Smart Contracts Guide](./references/soroban_contracts.md) - Contract deployment, invocation, auth
- [Smart Accounts Guide](./references/smart_accounts.md) - OZ kit core: config, wallet create/connect, signer types, transactions, credentials, external signers, events, indexer
- [Smart Accounts - Policies](./references/smart_accounts_policies.md) - Signer management, context rules, policies, multi-signer operations
- [Smart Accounts - WebAuthn](./references/smart_accounts_webauthn.md) - WebAuthn providers and storage adapters for Android, iOS, and Web
- [XDR Guide](./references/xdr.md) - XDR encoding/decoding and debugging
- [Troubleshooting Guide](./references/troubleshooting.md) - Error codes, platform & environment info
- [Security Guide](./references/security.md) - Platform-specific key storage, production deployment
- [SEP Implementations](./references/sep.md) - SEP protocols: TOML, Federation, Web Auth, deposits, KYC
- [Advanced Features](./references/advanced.md) - Multi-sig, sponsorship, fee bumps, liquidity pools, muxed accounts, async submission
- [API Reference (Signatures)](./references/api_reference.md) - Public class and member signatures, except XDR types, deprecated API, and top-level functions (grep for any class or method not covered above)

## Common Pitfalls

**Dart null safety:** A bare `KeyPair kp;` declaration is a compile error. Assign immediately, use `late KeyPair kp;` (throws if read before assignment), or declare nullable `KeyPair? kp;` and null-check before use.

**Amounts and prices are always Strings:** Payment amounts and balances are decimal strings with at most seven significant fractional digits after trailing zeros are ignored; the network carries them as 64-bit integer stroops (1 XLM = 10,000,000 stroops). Prices are decimal strings too, but `Price.fromString` approximates them to a signed-int32 fraction, so no seven-digit rule applies. It rejects malformed syntax, zero, and any value no int32 fraction can carry.
```dart
// WRONG: numeric amount, loses precision
double amount = 100.1234567;

// CORRECT: string amount
String amount = '100.1234567';
```

**Sequence number management:** `TransactionBuilder.build()` advances the source account's sequence number; reload the account before building the next transaction and never increment it by hand (`tx_bad_seq` otherwise). The WRONG/CORRECT pair and specific future sequences: Manual Sequence Numbers in [Advanced Features](./references/advanced.md).

**Missing signatures show at two levels:** `tx_bad_auth` when the transaction signatures miss the source account's low threshold, `op_bad_auth` (inside `tx_failed`) when an operation's source account misses the threshold of that operation.
```dart
// From the section Transaction Submission Errors: response (SubmitTransactionResponse)
// WRONG: checking only the operation codes misses tx_bad_auth
// CORRECT: check both levels
String? txCode = response.extras?.resultCodes?.transactionResultCode;
List<String?>? opCodes = response.extras?.resultCodes?.operationsResultCodes;
bool badAuth = txCode == 'tx_bad_auth' || (opCodes?.contains('op_bad_auth') ?? false);
```

**Fee calculation:** The fee is per operation. For a transaction with N operations at `setMaxOperationFee(200)`, the total fee is N * 200 stroops. The minimum base fee is 100 stroops per operation.

**Two HTTP clients:** Horizon uses `package:http`, Soroban RPC uses `package:dio`. Custom HTTP client configuration differs between the two.

**Web platform restrictions:** `StellarSDK.httpOverrides` throws `UnsupportedError` on web; `SorobanServer.httpOverrides` is ignored on web (no-op). Only use on non-web platforms.
